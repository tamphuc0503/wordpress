To update the js component:
===========================

Goto ..\enfold\dev


https://dotlottie.github.io/player-component/
https://docs.lottiefiles.com/dotlottie-player/

npm install --save @dotlottie/player-component

Copy  ..\enfold\dev\node_modules\@dotlottie\player-component\dist\dotlottie-player.js to ../config-lottie-animations/assets/lottie-player/dotlottie-player.js



----------------------

The following component for .json is supported in js above - so no need to install this:

https://docs.lottiefiles.com/lottie-player/components/lottie-player/installation

npm install --save @lottiefiles/lottie-player

Copy ..\enfold\dev\node_modules\@lottiefiles\lottie-player\dist\lottie-player.js to ../config-lottie-animations/assets/lottie-player/lottie-player.js


